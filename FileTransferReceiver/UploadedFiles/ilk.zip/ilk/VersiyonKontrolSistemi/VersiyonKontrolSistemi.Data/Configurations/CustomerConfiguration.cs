﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using VersiyonKontrolSistemi.Core.Entities;

namespace VersiyonKontrolSistemi.Data.Configurations
{
    public class CustomerConfiguration : IEntityTypeConfiguration<Customer>
    {
        public void Configure(EntityTypeBuilder<Customer> builder)
        {
            builder.ToTable("Customers");

            builder.HasKey(c => c.Id);

            builder.Property(c => c.Name)
                   .IsRequired()
                   .HasMaxLength(100);

            builder.Property(c => c.Code)
                   .IsRequired()
                   .HasMaxLength(50);

            builder.HasIndex(c => c.Code)
                   .IsUnique();

            builder.Property(c => c.IPAddress)
                   .HasMaxLength(45);

            builder.Property(c => c.IsActive)
                   .HasDefaultValue(true);

            builder.Property(c => c.CreatedDate)
                   .HasDefaultValueSql("GETDATE()");
        }
    }
}
