﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Reflection.Emit;
using VersiyonKontrolSistemi.Core.Entities;
using VersiyonKontrolSistemi.Data.Configurations;

namespace VersiyonKontrolSistemi.Data.Context
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }
        public DbSet<Customer> Customers { get; set; }
        public DbSet<Application> Applications { get; set; }
        public DbSet<CustomerApplication> CustomerApplications { get; set; }
        public DbSet<UpdateRequest> UpdateRequests { get; set; }
        public DbSet<VersionDefinition> VersionDefinitions { get; set; }
        public DbSet<SystemLog> SystemLogs { get; set; }
        public DbSet<ScheduledUpdate> ScheduledUpdates { get; set; }
        public DbSet<CriticalUpdate> CriticalUpdates { get; set; }
        public DbSet<VersionRollbackRequest> VersionRollbackRequests { get; set; }


        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new CustomerConfiguration());
        }
    }
}
