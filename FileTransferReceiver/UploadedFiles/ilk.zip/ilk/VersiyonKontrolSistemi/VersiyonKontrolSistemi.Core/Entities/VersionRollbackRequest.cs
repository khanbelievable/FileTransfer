﻿using System;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class VersionRollbackRequest
    {
        public int Id { get; set; }

        public int CustomerId { get; set; }
        public Customer Customer { get; set; }

        public int VersionId { get; set; }
        public VersionDefinition VersionDefinition { get; set; }

        public DateTime RollbackDate { get; set; }

        public string RequestedBy { get; set; }

        public RollbackStatus Status { get; set; }  // Beklemede, Tamamlandı, Reddedildi

        public string? Notes { get; set; }
    }
}
