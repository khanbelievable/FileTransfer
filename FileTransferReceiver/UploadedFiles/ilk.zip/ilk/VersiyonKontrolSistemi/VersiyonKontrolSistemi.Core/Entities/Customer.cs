﻿using System;
using System.Collections.Generic;
using static System.Net.Mime.MediaTypeNames;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class Customer
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Code { get; set; }

        public string IPAddress { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        public DateTime? LastConnectionDate { get; set; }

        // Navigation Properties
        public ICollection<CustomerApplication> CustomerApplications { get; set; }
        public ICollection<UpdateRequest> UpdateRequests { get; set; }
        public ICollection<SystemLog> SystemLogs { get; set; }
        public ICollection<ScheduledUpdate> ScheduledUpdates { get; set; }
        public ICollection<VersionRollbackRequest> VersionRollbackRequests { get; set; }

    }
}
