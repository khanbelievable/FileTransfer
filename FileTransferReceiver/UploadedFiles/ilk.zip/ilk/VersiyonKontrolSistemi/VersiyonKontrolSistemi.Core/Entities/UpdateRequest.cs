﻿using System;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class UpdateRequest
    {
        public int Id { get; set; }

        //  FK'ler
        public int CustomerId { get; set; }
        public Customer Customer { get; set; }

        public int VersionId { get; set; }
        public VersionDefinition VersionDefinition { get; set; }

        public RequestType RequestType { get; set; } // Otomatik, Manuel, Kritik

        public RequestSource RequestSource { get; set; } // API, Web UI, Windows Service

        public DateTime RequestDate { get; set; }

        public RequestStatus Status { get; set; } // Başarılı, Başarısız, Beklemede

        public string? ResponseMessage { get; set; }

        public bool IsCritical { get; set; }

        public string? ScheduledBy { get; set; }

        public string? ExecutedBy { get; set; }

        public DateTime? ExecutionDate { get; set; }
    }
}
