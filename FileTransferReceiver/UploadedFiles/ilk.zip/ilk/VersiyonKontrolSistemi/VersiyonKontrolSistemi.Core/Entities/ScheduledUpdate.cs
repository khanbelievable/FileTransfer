﻿using System;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class ScheduledUpdate
    {
        public int Id { get; set; }

        public int? CustomerId { get; set; }
        public Customer? Customer { get; set; }

        public int VersionId { get; set; }
        public VersionDefinition VersionDefinition { get; set; }

        public DateTime StartDate { get; set; }

        public DateTime EndDate { get; set; }

        public bool IsActive { get; set; } = true;

        public string ScheduledBy { get; set; }
    }
}
