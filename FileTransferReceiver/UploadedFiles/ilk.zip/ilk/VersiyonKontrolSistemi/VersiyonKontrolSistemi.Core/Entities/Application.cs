﻿using System;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class Application
    {
        public int Id { get; set; }

        public string Name { get; set; }

        public string Type { get; set; }  // Web, Mobil, Masaüstü gibi

        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.Now;

        //Navigation

        public ICollection<CustomerApplication> CustomerApplications { get; set; }
    }
}
