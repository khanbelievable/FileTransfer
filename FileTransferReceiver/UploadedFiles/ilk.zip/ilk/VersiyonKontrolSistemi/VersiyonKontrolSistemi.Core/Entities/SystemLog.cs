﻿using System;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class SystemLog
    {
        public int Id { get; set; }

        public DateTime LogDate { get; set; }

        public LogLevel LogLevel { get; set; }  // Info, Warning, Error

        public LogSource Source { get; set; }  // API, Service, Web UI, vb.

        public string Message { get; set; }

        public string? StackTrace { get; set; }

        public string? UserId { get; set; }

        public int? CustomerId { get; set; }
        public Customer? Customer { get; set; }
    }
}
