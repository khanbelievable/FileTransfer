﻿using System;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class CustomerApplication
    {
        public int Id { get; set; }

        public int CustomerId { get; set; }
        public Customer Customer { get; set; }

        public int ApplicationId { get; set; }
        public Application Application { get; set; }

        public bool IsActive { get; set; } = true;

        public DateTime CreatedDate { get; set; } = DateTime.Now;
    }
}
