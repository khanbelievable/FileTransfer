﻿using System;
using VersiyonKontrolSistemi.Core.Enums;

namespace VersiyonKontrolSistemi.Core.Entities
{
    public class CriticalUpdate
    {
        public int Id { get; set; }

        public int VersionId { get; set; }
        public VersionDefinition VersionDefinition { get; set; }

        public DateTime ReleaseDate { get; set; }

        public string Description { get; set; }

        public bool IsGlobal { get; set; }

        public string CreatedBy { get; set; }
    }
}
