﻿namespace VersiyonKontrolSistemi.Core.Enums
{
    public enum RollbackStatus
    {
        Beklemede = 0,
        Tamamlandi = 1,
        Reddedildi = 2
    }
}
