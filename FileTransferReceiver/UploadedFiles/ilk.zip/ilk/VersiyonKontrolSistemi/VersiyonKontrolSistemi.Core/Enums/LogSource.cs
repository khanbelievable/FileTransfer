﻿namespace VersiyonKontrolSistemi.Core.Enums
{
    public enum LogSource
    {
        API = 0,
        Service = 1,
        WebUI = 2
    }
}
