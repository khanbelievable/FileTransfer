﻿namespace VersiyonKontrolSistemi.Core.Enums
{
    public enum LogLevel
    {
        Info = 0,
        Warning = 1,
        Error = 2
    }
}
