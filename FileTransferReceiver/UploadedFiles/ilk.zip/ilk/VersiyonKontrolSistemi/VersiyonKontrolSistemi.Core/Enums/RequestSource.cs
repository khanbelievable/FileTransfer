﻿namespace VersiyonKontrolSistemi.Core.Enums
{
    public enum RequestSource
    {
        API = 0,
        WebUI = 1,
        WindowsService = 2
    }
}
