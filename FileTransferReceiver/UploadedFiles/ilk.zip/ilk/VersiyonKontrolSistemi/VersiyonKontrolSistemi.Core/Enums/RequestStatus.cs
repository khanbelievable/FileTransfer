﻿namespace VersiyonKontrolSistemi.Core.Enums
{
    public enum RequestStatus
    {
        Beklemede = 0,
        Basarili = 1,
        Basarisiz = 2
    }
}
