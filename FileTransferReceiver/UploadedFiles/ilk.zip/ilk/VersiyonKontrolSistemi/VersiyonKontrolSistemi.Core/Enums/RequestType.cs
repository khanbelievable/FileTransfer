﻿namespace VersiyonKontrolSistemi.Core.Enums
{
    public enum RequestType
    {
        Otomatik = 0,
        Manuel = 1,
        Kritik = 2
    }
}
